def setup():
    print("Welcome to EmailService, To get started, please turn on less secure apps in gmail settings.")
    return "Done"
